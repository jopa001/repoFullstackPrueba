class Location < ApplicationRecord
	has_many :reports
end
