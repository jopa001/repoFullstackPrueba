Rails.application.routes.draw do

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
#resources :location  #resources tiene la mayor parte de definiciones get post ...
					#al ejecutar db:seed, podre ver todas las rutas con rails routes 

	namespace :api do
		post 'auth' => 'user_token#create'
		namespace :v1 do
			resources :location do
				resources :report   #si tuviera otro namespace entonces 
									#tendrìa que crear otra carpeta dentro de location para report
			end
		end
	end

end
