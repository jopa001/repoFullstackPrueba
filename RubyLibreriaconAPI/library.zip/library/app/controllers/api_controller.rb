class ApiController < ApplicationController
	def books
		libros = Book.all

		render json: {
			books: libros
			#books: books.each do |b| {
			#	name:
			#}
		}
	end

	def show
		book_id = params[:book_id]
		book = Book.find(book_id)
		render json: {
			id: book.id,
			name: book.name
		}
	end
end
