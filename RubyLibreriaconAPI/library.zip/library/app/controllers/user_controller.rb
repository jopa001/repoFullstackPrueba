class UserController < ApplicationController
before_action :authenticate_user!

	# con el autenticado se asegura que alguien està conectado
	def index
		@books = current_user.books  #esta es la variable del usuario logeado,
	end


	#Este es el metodo que se conecta con el submit del formulario
	def add_book
		book_params = params.require(:book).permit(:id)
		book = Book.find(book_params[:id])

		unless book.nil? 
			current_user.books.push(book)
		end
		redirect_to :controller => 'user', :action => 'index'
	end
end
