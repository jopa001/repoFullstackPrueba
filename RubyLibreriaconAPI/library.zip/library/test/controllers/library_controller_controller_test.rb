require 'test_helper'

class LibraryControllerControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get library_controller_index_url
    assert_response :success
  end

end
