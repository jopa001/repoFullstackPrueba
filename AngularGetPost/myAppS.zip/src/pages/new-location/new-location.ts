import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';


@Component({
  selector: 'page-new-location',
  templateUrl: 'new-location.html',
})
export class NewLocationPage {

	public name: string;

  constructor(public navCtrl: NavController, public api: ApiProvider) {
  }

  public crearUbicacion(): void { 
      const location = {
      	location: {
      		name: this.name
      	}
    }
  	this.api.createLocations(location).subscribe((response) => {
  	this.name="Cargado con exito";

  	}, (error) => {
  	console.error(error);
  });

  }
}