import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpHeaders } from '@angular/common/http';

/*
  Generated class for the ApiProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ApiProvider {
 public token: string;
 private url = "https://pure-hollows-29440.herokuapp.com/api/v1/user_token";
 private getLocation = 'https://pure-hollows-29440.herokuapp.com/api/v1/locations';
 private postLocation = 'https://pure-hollows-29440.herokuapp.com/api/v1/locations';

  constructor(public http: HttpClient) {
    console.log('Hello ApiProvider Provider');
  }

  public auth(params: any): any {    /* retorno de tipo any */
  	return this.http.post(this.url,params)
  }

  public getLocations(): Observable<any> {   /* observable de tipo any */ 
    const headers = new HttpHeaders ({
      'Authorization': 'Bearer ' + this.token

    });
    return this.http.get(this.getLocation, {
      headers: headers
    });
  }

  public createLocations(params): Observable<any> {   /* observable de tipo any */ 
    const headers = new HttpHeaders ({
      'Authorization': 'Bearer ' + this.token
    });
    return this.http.post(this.postLocation, params, {
      headers: headers
    });
    
  }

		  /* 
		correo: fullstack@gmail.com
		passwo: 123456

		*/

/*
{
  "location" :{
    "name": "Medellin"
  } 
}
*/


}
