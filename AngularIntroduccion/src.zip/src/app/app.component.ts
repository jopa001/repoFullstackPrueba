import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  public items: Array<string> = [];

  constructor () {
  	/*this.items.push('cadena Juan 1');
  	this.items.push('cadena Arturo 2');
  	this.items.push('cadena Diana 3');
  	this.items.push('cadena Maria 4');
  	this.items.push('cadena Ana 5');
  	*/
  }

  public agregar (n: string) {
    this.items.push(n);
  }

}

  

