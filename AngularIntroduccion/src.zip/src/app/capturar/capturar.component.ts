import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-capturar',
  templateUrl: './capturar.component.html',
  styleUrls: ['./capturar.component.css']
})
export class CapturarComponent implements OnInit {

	public masqueName: string;
	
	@Output()
	public enviar = new EventEmitter<string>();
	
  constructor() { }

  ngOnInit() {
  }

  public agregar () {
	  	this.enviar.emit(this.masqueName);

	  	/*alert(this.masqueName);
	  	this.masqueName="";
	  	*/

	  }

}
