class LibraryControllerController < ApplicationController
  def index
  	
  end
end
