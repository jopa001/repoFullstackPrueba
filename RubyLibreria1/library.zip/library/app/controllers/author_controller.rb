class AuthorController < ApplicationController
  
  before_action :authenticate_user!  

  def index
  	@authors = Author.all
  	@books = Book.all  #este se puede quitar es accesible desde autor por la llave foranea
  end
end
