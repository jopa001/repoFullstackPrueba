Rails.application.routes.draw do
  get 'library_controller/index'
  devise_for :users
  #root to: "author#index"
  root to: "library_controller#index"   #cambie la ruta a otro
  get 'autores', to: "author#index"

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
