import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage {
	public email: string; 
	public password: string; 

  constructor(public navCtrl: NavController, public api: ApiProvider) {

  }

  public send(): void {
  	const auth = {
  		auth: {
			email: this.email ,
			password: this.password
		}
  	}

	this.api.auth(auth).subscribe((response: any) => {
		console.log(response);
	}, (error) => {
		console.log(error);
	});

	//console.log('Pasa aca');
	console.log(auth);

  }

}
