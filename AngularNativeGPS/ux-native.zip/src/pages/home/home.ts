import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ActionSheetController, AlertController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage {

  constructor(public actionSheetCtrl: ActionSheetController,
  			public as: ActionSheetController,
  			public ac: AlertController,
  			public geolocation: Geolocation) { }

  presentActionSheet() {
  	
    const actionSheet = this.ac.create({
      title: 'Modify your album',
      buttons: [
        {
          text: 'Destructive',
          role: 'destructive',
          handler: () => {
          	const alert = this.ac.create({
		      title: 'Alerta',
		      subTitle: 'Destructive clicked',
		      buttons: ['Aceptar']
		      });
		    alert.present();
		  }
        },{
          text: 'Archive',
          handler: () => {
            alert('Archive clicked');
          }
        },{
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            alert('Cancel clicked');
          }
        }
      ]
    });
    actionSheet.present();
  }

  public ubicar(): void {
  	this.geolocation.getCurrentPosition().then((p: Position) => {
  		console.log(p);
  	});
  }

}