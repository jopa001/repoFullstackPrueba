import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { FormsModule } from '@angular/forms';
import { Storage } from '@ionic/storage';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html' 
})
export class HomePage {
	public llave: string;
	public valor: string;
	
  constructor(public navCtrl: NavController, 
  			public storage: Storage) {
 
  }

  public guardar(): void {
  	localStorage.setItem(this.llave, this.valor);
  	//alert("si llama");
  }

  public leer(): void { 
  	alert(localStorage.getItem(this.llave));
  	//alert(this.llave);
  	//localStorage.setItem(this.llave, this.valor);
  	//alert("si llama");
  }

  public guardarStorage(): void { 
  	this.storage.set(this.llave, this.valor);
  }

  public leerStorage(): void {
  	this.storage.get(this.llave).then((valor) => {
    console.log('El valor es:', valor);
    alert('El valor es: '+valor);
  });
  }

}
