class Report < ApplicationRecord
  belongs_to :location
end
